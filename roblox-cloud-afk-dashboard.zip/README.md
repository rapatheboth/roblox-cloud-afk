# Roblox Cloud AFK Dashboard — starter project

Paket ini berisi dashboard web statis dan API Cloudflare Worker untuk pemantauan status.

## Penting: batas kemampuan
- Cloudflare Workers adalah serverless request handler, bukan komputer virtual yang menjalankan Roblox Player.
- Tombol START/STOP hanya menyimpan `desiredState` di KV. Tombol tersebut **tidak** menjalankan atau menghentikan Roblox.
- Untuk benar-benar menjalankan aplikasi/game diperlukan mesin runner terpisah yang kompatibel. Jangan gunakan password Roblox, cookie `.ROBLOSECURITY`, OTP, atau token login di proyek ini.
- Tidak ada jaminan layanan cloud gratis 24/7 tanpa batas. Periksa kuota dan ketentuan penyedia.

## Isi
- `index.html` — dashboard frontend.
- `worker/worker.js` — API backend.
- `worker/wrangler.toml` — konfigurasi Worker contoh.

## A. Deploy backend ke Cloudflare
1. Buat Worker bernama `roblox-cloud-api`.
2. Buka editor kode Worker dan ganti seluruh isi `worker.js` dengan isi `worker/worker.js`.
3. Deploy.
4. Di Worker Settings → Bindings, tambahkan **KV Namespace** dengan variable name `AFK_KV`. Buat namespace baru, misalnya `roblox-afk-state`.
5. Di Worker Settings → Variables and Secrets, tambahkan secret bernama `DASHBOARD_KEY`. Buat key acak yang panjang. Simpan baik-baik; jangan kirim ke orang lain.
6. Deploy ulang jika diminta.
7. Tes `https://NAMA-WORKER.NAMA-AKUN.workers.dev/health`. Harus mengembalikan JSON `ok: true`.

> Jangan menaruh `DASHBOARD_KEY` di kode Worker atau GitHub. Simpan sebagai Secret di Cloudflare.

## B. Deploy dashboard ke GitHub Pages
1. Unggah `index.html` ke root repository GitHub.
2. Repository → Settings → Pages.
3. Pada Build and deployment, pilih **Deploy from a branch**.
4. Branch `main`, folder `/ (root)`, lalu Save.
5. Tunggu beberapa menit sampai URL GitHub Pages aktif.

## C. Hubungkan dashboard
1. Buka URL GitHub Pages.
2. Masukkan URL Worker, misalnya `https://roblox-cloud-api.nama-akun.workers.dev`.
3. Masukkan `DASHBOARD_KEY` yang dibuat di Cloudflare.
4. Tekan **Simpan koneksi**, lalu **Tes koneksi**.
5. Tombol Minta START/STOP mengubah status perintah di KV saja.

## Endpoint API
- `GET /health` — pemeriksaan layanan.
- `GET /api/status` — membaca status.
- `POST /api/command` — `{ "action": "start" | "stop" }`, memerlukan Bearer key.
- `POST /api/heartbeat` — `{ "label": "nama runner" }`, memerlukan Bearer key.

Contoh header untuk endpoint yang dilindungi:
`Authorization: Bearer YOUR_DASHBOARD_KEY`

## Troubleshooting
- **401**: secret `DASHBOARD_KEY` di Cloudflare dan key di dashboard tidak sama.
- **503 KV belum dikonfigurasi**: binding KV belum dibuat dengan nama tepat `AFK_KV`.
- **Failed to fetch**: cek URL Worker, deploy terbaru, dan koneksi internet.
- **Dashboard Pages tidak berubah**: pastikan `index.html` ada di root branch dan Pages memakai `main / (root)`.

## Privasi
Jangan pernah memasukkan password, OTP, cookie, atau token autentikasi Roblox. API ini tidak membutuhkan data login Roblox.
